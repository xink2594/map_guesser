export const WORLD_SPOTS = [
    {
      id: 1,
      name: '',
      image: require('../../assets/img/world/eiffel.png'),
      coordinates: {
        latitude: 48.8584,
        longitude: 2.2945
      }
    },
    // {
    //   id: 2,
    //   name: '泰姬陵',
    //   image: require('../../assets/img/world/tajmahal.jpg'),
    //   coordinates: {
    //     latitude: 27.1751,
    //     longitude: 78.0421
    //   }
    // },
    // {
    //   id: 3,
    //   name: '自由女神像',
    //   image: require('../../assets/img/world/liberty.jpg'),
    //   coordinates: {
    //     latitude: 40.6892,
    //     longitude: -74.0445
    //   }
    // },
    // 可以继续添加更多世界景点
  ];